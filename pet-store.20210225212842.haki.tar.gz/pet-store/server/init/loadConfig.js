/*
 * loadConfig.js
 */
'use strict';
module.exports = function() {
  const fs = require('fs');
  const _ = require('lodash');
  const YAML = require('yaml');

  // const BASE_CONFIG = './config/config.json';
  const BASE_CONFIG = './config/config.yaml';
  const DEFAULT = 'default';
  const DEFAULT_ENV = 'development';
  const DEBUG_THIS = false;

  function logConfig(cnfg, name) {
    if (DEBUG_THIS) {
      if (cnfg == null) {
        console.log(name, 'is null');
      } else {
        // console.log(`${name}: ${JSON.stringify(cnfg, undefined, cnfg.json_indentation)}`);
        console.log(`${name}: ${YAML.stringify(cnfg)}`);
      }
    }
  } // logConfig

  function checkAndLoadConfig(filePath) {
    try {
      fs.statSync(filePath);
      // return JSON.parse(fs.readFileSync(filePath));
      return YAML.parse(fs.readFileSync(filePath, {encoding: 'utf8'}));
    } catch (err) {
      /* file not accessible: ignore the error */
      console.error('checkAndLoadConfig', err);
      return null;
    }
  } // checkAndLoadConfig

  function layerConfig(baseConfig, env) {
    if ((baseConfig != null) && (baseConfig[env] != null)) {
      // console.log("layerConfig return baseConfig", env);
      return baseConfig[env];
    } else {
      // console.log("layerConfig return null", env);
      return null;
    }
  } // layerConfig

  const config = checkAndLoadConfig(BASE_CONFIG);
  logConfig(config, 'config');

  const defaultConfig = layerConfig(config, DEFAULT);
  logConfig(defaultConfig, 'defaultConfig');

  const environment = process.env.NODE_ENV || DEFAULT_ENV;
  const environmentConfig = layerConfig(config, environment);
  logConfig(environmentConfig, 'environmentConfig');

  /* environment overrides default */
  global.gConfig = _.merge(defaultConfig, environmentConfig);
  logConfig(global.gConfig, 'global.gConfig');
  if (typeof process.env.NODE_APP_INSTANCE != 'undefined') {
    global.gConfig.nodeAppInstance = process.env.NODE_APP_INSTANCE;
  }
}; // module.exports
