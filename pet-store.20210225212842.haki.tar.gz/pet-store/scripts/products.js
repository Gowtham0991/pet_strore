const productCollection = db.getCollection('product');
print('update collection', productCollection);

productCollection.remove({})

productCollection.insertMany(
[
  {
    "sku": "82",
    "name": "Bicycle Cat Cart",
    "description": "Firm on the outside, all comfy and cozy on the inside, this cat cart for your bikes is the perfect companion for yout travel-loving cat!",
    "price": 29,
    "categories": "Cats|Travel",
    "image_url": "/images/Group82.png",
    "url": "/product/82",
    "group_id": "82",
    "in_stock": true
  },
  {
    "sku": "83",
    "name": "Doggy Carry Shoulder Bag",
    "description": "For adventurers (and their human owners), an all-terrain water resistant bag",
    "price": 49,
    "categories": "Dogs|Travel",
    "image_url": "/images/Group83.png",
    "url": "/product/83",
    "group_id": "83",
    "in_stock": true
  },
  {
    "sku": "84",
    "name": "GoodNightz Fluffy Cat Blanket",
    "description": "Sweet dreams are made of this. 'Nuf said!",
    "price": 15,
    "categories": "Cats|Bedding",
    "image_url": "/images/Group84.png",
    "url": "/product/84",
    "group_id": "84",
    "in_stock": true
  },
  {
    "sku": "85",
    "name": "The Original Aquanaut Cat Carry Bag",
    "description": "The ultimate in shouldered cat carrying. Your cat, and your lower back, deserve The Aquanaut.",
    "price": 119,
    "categories": "Cats|Travel",
    "image_url": "/images/Group85.png",
    "url": "/product/85",
    "group_id": "85",
    "in_stock": true
  },
  {
    "sku": "119",
    "name": "Cat Scratch Tower (Midi)",
    "description": "Simple, effective and portable. Let your cat keep its claws in a scratch-tastis shape.",
    "price": 29,
    "categories": "Cats|Toys",
    "image_url": "/images/Group119.png",
    "url": "/product/119",
    "group_id": "119",
    "in_stock": true
  },
  {
    "sku": "120",
    "name": "Extreme Cat Distractor",
    "description": "Your cat has seen it all, and for everything you throw at him you're only rewarded with a sleepy yawn? Well, try this!",
    "price": 15,
    "categories": "Cats|Toys",
    "image_url": "/images/Group120.png",
    "url": "/product/120",
    "group_id": "120",
    "in_stock": true
  },
  {
    "sku": "122",
    "name": "Atheletic Performance MAX Cat Collar",
    "description": "For cats who love jogging with their humans, with patented Catdex(R) V3 synthetic fabric.",
    "price": 39,
    "categories": "Cats|Travel",
    "image_url": "/images/Group122.png",
    "url": "/product/122",
    "group_id": "122",
    "in_stock": true
  },
  {
    "sku": "123",
    "name": "Scratchy Chair",
    "description": "Let your cat scratch while is sits around like the lazy prince(ss) that it is ",
    "price": 19,
    "categories": "Cats|Toys",
    "image_url": "/images/Group123.png",
    "url": "/product/123",
    "group_id": "123",
    "in_stock": true
  },
  {
    "sku": "124",
    "name": "Bag it Home",
    "description": "Claw-resistant baggy home for your cat. Finally, a fun hideout that will not get shredded in a hearbeat.",
    "price": 29,
    "categories": "Cats|Bedding",
    "image_url": "/images/Group124.png",
    "url": "/product/124",
    "group_id": "124",
    "in_stock": true
  },
  {
    "sku": "125",
    "name": "Infinity Vortex Tunnel",
    "description": "Your cat's trying to control your mind, so far with only limited success? Get it this Infinity Vortex Tunnel, and let it happily assimilate you and your friends.",
    "price": 38,
    "categories": "Cats|Toys",
    "image_url": "/images/Group125.png",
    "url": "/product/125",
    "group_id": "125",
    "in_stock": true
  },
  {
    "sku": "126",
    "name": "All Natural Cat Bowl",
    "description": "Cats love bowls, you also love keeping your bowls intact. Hence, a perfect smooth bowl just for your cat.",
    "price": 15,
    "categories": "Cats|Bedding",
    "image_url": "/images/Group126.png",
    "url": "/product/126",
    "group_id": "126",
    "in_stock": true
  },
  {
    "sku": "127",
    "name": "SpoiledBratCat Scratcher",
    "description": "For those cats who are just too lazy to ever do any claw practice - the holy grail of comfy scrtach toys",
    "price": 39,
    "categories": "Cats|Toys",
    "image_url": "/images/Group127.png",
    "url": "/product/127",
    "group_id": "127",
    "in_stock": true
  },
  {
    "sku": "128",
    "name": "Catzz Rustic Rusty Hideaway",
    "description": "Your cat loves only cramped, old and dirty spaces? Get them this Rusty Hideaway, which only looks rusty - but with an anti-bacterial coating!",
    "price": 49,
    "categories": "Cats|Bedding",
    "image_url": "/images/Group128.png",
    "url": "/product/128",
    "group_id": "128",
    "in_stock": true
  },
  {
    "sku": "131",
    "name": "Pugsies' Fluffy Paradise",
    "description": "The ultimate fluff! You and your pug need not look any further - it's simply the fluffiest little blanket, guaranteed.",
    "price": 29,
    "categories": "Dogs|Bedding",
    "image_url": "/images/Group131.png",
    "url": "/product/131",
    "group_id": "131",
    "in_stock": true
  },
  {
    "sku": "132",
    "name": "Charlie's Work Shirt",
    "description": "When your pug is busy doing an honest day's work, they need a trustworthy, sturdy shirt to help protect their fur",
    "price": 19,
    "categories": "Dogs|Clothing",
    "image_url": "/images/Group132.png",
    "url": "/product/132",
    "group_id": "132",
    "in_stock": true
  },
  {
    "sku": "133",
    "name": "Unrecognizable Doggie Doll",
    "description": "Your doggie needs a doll they can play with - and tear apart. With the Unrecognizable Doll, you won't feel bad for the little doll, as it comes unrecognizable straight from the factory line!",
    "price": 9,
    "categories": "Dogs|Toys",
    "image_url": "/images/Group133.png",
    "url": "/product/133",
    "group_id": "133",
    "in_stock": true
  },
  {
    "sku": "134",
    "name": "Canine Cardboard Home",
    "description": "If they love their cardboard boxes, why not get them one that will actually last? With world-reknown reinforced gorilla cardboard.",
    "price": 15,
    "categories": "Dogs|Bedding",
    "image_url": "/images/Group134.png",
    "url": "/product/134",
    "group_id": "134",
    "in_stock": true
  },
  {
    "sku": "135",
    "name": "Le Beret",
    "description": "Your dog always had glam. Now let it show.",
    "price": 38,
    "categories": "Dogs|Clothing",
    "image_url": "/images/Group135.png",
    "url": "/product/135",
    "group_id": "135",
    "in_stock": true
  },
  {
    "sku": "136",
    "name": "Groucho Me Silly (Dog Version)",
    "description": "For them silly dogs and happy occasions, a holiday treat!",
    "price": 6,
    "categories": "Dogs|Toys",
    "image_url": "/images/Group136.png",
    "url": "/product/136",
    "group_id": "136",
    "in_stock": true
  },
  {
    "sku": "137",
    "name": "FetchThat(TM) Beach Ball",
    "description": "Sand, salty water or sharp teeth - you need a ball to throw arround see-side, that can take all your dog's gonna throw around at him.",
    "price": 19,
    "categories": "Dogs|Toys",
    "image_url": "/images/Group137.png",
    "url": "/product/137",
    "group_id": "137",
    "in_stock": true
  },
  {
    "sku": "138",
    "name": "Stylish Skinny Collar",
    "description": "Your skinny, short-fur dog deserves a solid, stylish collar to match their lifestyle.",
    "price": 29,
    "categories": "Dogs|Travel",
    "image_url": "/images/Group138.png",
    "url": "/product/138",
    "group_id": "138",
    "in_stock": true
  },
  {
    "sku": "139",
    "name": "Little Bandit Handkerchief",
    "description": "Dog's a little bandit? Complete the look with these Banditos handkerchiefs.",
    "price": 8,
    "categories": "Dogs|Toys",
    "image_url": "/images/Group139.png",
    "url": "/product/139",
    "group_id": "139",
    "in_stock": true
  },
  {
    "sku": "140",
    "name": "Nerd Glasses",
    "description": "Some dogs are just big nerds - let them look the part.",
    "price": 19,
    "categories": "Dogs|Toys",
    "image_url": "/images/Group140.png",
    "url": "/product/140",
    "group_id": "140",
    "in_stock": true
  },
  {
    "sku": "142",
    "name": "\"Undestroyablez Squishiez\": Little Piggy",
    "description": "Your dog is gonna try hard, but this little piggy is tougher than it looks!",
    "price": 14,
    "categories": "Dogs|Toys",
    "image_url": "/images/Group142.png",
    "url": "/product/142",
    "group_id": "142",
    "in_stock": true
  }
]
);
