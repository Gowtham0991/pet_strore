db.createUser({user:"user2", pwd:"d679b!rSXWZxyG98", roles:[{role:"readWriteAnyDatabase", db:"admin"}]})
