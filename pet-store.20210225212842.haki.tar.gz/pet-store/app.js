const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieSession = require('cookie-session');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const uuidv4 = require('uuid/v4');
const homepageRouter = require('./routes/homepage');
const productsRouter = require('./routes/product');
const cateogryRouter = require('./routes/category');
const cartRouter = require('./routes/cart');
const mongoose = require('mongoose');
const app = express();

// initialize global.gConfig
require('./server/init/loadConfig')();

// configure mongoose
mongoose.set('useCreateIndex', true);
// custom settings
if (global.gConfig.mongoose) {
  const keys = Object.keys(global.gConfig.mongoose);
  for (let i=0; i<keys.length; i++) {
    const key = keys[i];
    mongoose.set(key, global.gConfig.mongoose[key]);
  } // for
} // if

// connect to database
const db_location = 'mongodb://' + global.gConfig.dbUser +
  ':' + global.gConfig.dbPassword +
  '@'+ global.gConfig.dbHost +
  ':' + global.gConfig.dbPort +
  '/' + global.gConfig.dbName;
console.log('db_location', db_location);
// var conn_db   = mongoose.createConnection(db_location);
mongoose.connect(db_location);

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

/** userId management */

app.use((req, res, next) => {
  let { userId } = req.cookies;
  if (!userId) {
    userId = uuidv4();
    res.cookie('userId', userId, { maxAge: 365 * 24 * 60 * 60 * 1000, httpOnly: true });
  }
  req.userId = userId;
  next();
});

/** session management */

app.use(cookieSession({
  name: 'session',
  secret: 'somesecretkeyhash',
}));

app.use((req, _res, next) => {
  if (req.session.isNew) { // cookieSession defines what is considered a new session
    req.session.sessionId = uuidv4();
  }
  req.sessionId = req.session.sessionId;
  // for the sake of simplicity the cart is stored in the session as well
  req.cart = req.session.cart || { total: 0, products: [] };
  req.session.cart = req.cart;
  next();
});

app.use('/', homepageRouter);
app.use('/product', productsRouter);
app.use('/category', cateogryRouter);
app.use('/cart', cartRouter);

// catch 404 and forward to error handler
app.use((req, res, next) => {
  next(createError(404));
});

// error handler
app.use((err, req, res, next) => {
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : null;

  res.status(err.status || 500);
  res.render('error');
  next();
});

module.exports = app;
