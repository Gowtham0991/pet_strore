const mongoose = require('mongoose');

function getAllProducts(callback) {
    let productModel = null;
    try {
      productModel = mongoose.model('product');
    } catch(err) {
      if (!productModel) {
        const productSchema = mongoose.Schema({
          "sku": String,
          "name": String,
          "description": String,
          "price": Number,
          "categories": String,
          "image_url": String,
          "url": String,
          "group_id": Number,
          "in_stock": Boolean
        },
        { collection: 'product' });
        productModel = mongoose.model('product', productSchema);
      } // if
    } // catch
    productModel.find({}, function(err, results) {
      if (err) {
        console.log(err);
        callback([]);
      } else {
        callback(results);
      }
    }).lean();
} // getAllProducts

function getCategory(category, itemsPerPage, page, callback) {
  getAllProducts(function(products) {
console.log('products', products);
    const items = products.filter(item => item.categories.toLowerCase().indexOf(category.toLowerCase()) > -1);
    const maxPage = (Math.ceil(items.length / itemsPerPage) - 1);
    const result = {
      products: items.slice(itemsPerPage * (page - 1), itemsPerPage * page),
      pagination: {
        currentPage: page,
        category: category.replace(/\|/g, '/'),
      },
    };
    if (page > 1) {
      result.pagination.prev = page - 1;
    }
    if (page <= maxPage) {
      result.pagination.next = page + 1;
    }
    callback(result);
  });
} // getCategory

function getProducts(skus, callback) {
  getAllProducts(function(products) {
    callback(products.filter(item => skus.indexOf(item.sku) > -1));
  });
} // getProducts

function getProduct(sku, callback) {
  getAllProducts(function(products) {
    callback(products.filter(item => item.sku.toString() === sku.toString()));
  });
} // getProduct

function getAll(itemsPerPage, page, callback) {
  getAllProducts(function(products) {
    const maxPage = (Math.ceil(products.length / itemsPerPage) - 1);
    const result = {
      products: products.slice(itemsPerPage * (page - 1), itemsPerPage * page),
      pagination: {
        currentPage: page,
        category: 'all',
      },
    };
    if (page > 1) {
      result.pagination.prev = page - 1;
    }
    if (page <= maxPage) {
      result.pagination.next = page + 1;
    }
    callback(result);
  });
} // getAll

function getRandom(items, callback) {
  getAllProducts(function(products) {
    const total = items < products.length ? items : products.length;
    let result = [];
    let currentIndex = 0;
    while (currentIndex < total) {
      const product = products[Math.floor(Math.random() * products.length)];
      if (result.indexOf(product) === -1) {
        result.push(product);
        currentIndex += 1;
      }
    }
    callback(result);
  });
} // getRandom

module.exports = {
  getAll,
  getProduct,
  getProducts,
  getCategory,
  getRandom,
};
