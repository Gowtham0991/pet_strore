// homepage.js
const router = require('express').Router();
const Product = require('../models/product');

const defaultHeroBanner = {
  // image: 'images/pets-3715733_1920.jpg',
  image: '/images/pets.jpg',
  title: 'We love your pets',
  subtitle: 'We stock hand-picked pet accessories from all over the world',
  cta: 'Go Shopping',
  link: '/category/all',
};

router.get('/', async (req, res) => {
  getPageContent(req, function(content) {
    const overlay = content.overlay;
    const heroBanner = content.heroBanner;
    const recommendations = content.recommendations;
    res.render('homepage', {
      overlay,
      heroBanner,
      recommendations,
      invertedHeader: true,
    });
  });
});


const defaultOverlay = {
  image: '/images/erda-estremera-581452-unsplash.png',
  title: 'Invest in your pet',
  content: 'Subscribe to our monthly treat box<br>and receive the items you love for a<br>great price, plus seasonal surprises',
  cta: 'Start Here',
  link: '/category/all',
};

function getPageContent(req, callback) {
  Product.getRandom(4, function(defaultRecommendations) {
    const content = {
      heroBanner: defaultHeroBanner,
      recommendations: defaultRecommendations,
    };
    if (req.originalUrl.includes('SALE')) {
      content.overlay = defaultOverlay;
    } else {
      content.overlay = undefined;
    }
    callback(content);
  });
}

module.exports = router;
